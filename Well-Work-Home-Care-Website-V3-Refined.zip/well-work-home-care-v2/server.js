require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const nodemailer = require("nodemailer");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const db = new Database("wellwork.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, booking_id TEXT UNIQUE, name TEXT NOT NULL,
 phone TEXT NOT NULL, email TEXT, service TEXT NOT NULL, patient TEXT, address TEXT,
 pin TEXT, start_date TEXT, duration TEXT, shift TEXT, notes TEXT, status TEXT DEFAULT 'New',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS enquiries (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, message TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS job_applications (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, email TEXT, role TEXT,
 experience TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({limit:"30kb"}));
app.use(express.static(path.join(__dirname,"public")));
app.use("/api/", rateLimit({windowMs:15*60*1000, limit:40, standardHeaders:true, legacyHeaders:false}));

function sendEmail(subject, text) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return Promise.resolve(false);
  const transporter = nodemailer.createTransport({
    host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT||587),
    secure:Number(process.env.SMTP_PORT)===465,
    auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}
  });
  return transporter.sendMail({from:process.env.SMTP_USER,to:process.env.ADMIN_EMAIL||"wellwork003@gmail.com",subject,text}).then(()=>true);
}
async function sendWhatsApp(message) {
  const {WHATSAPP_TOKEN,WHATSAPP_PHONE_NUMBER_ID,WHATSAPP_ADMIN_NUMBER}=process.env;
  if (!WHATSAPP_TOKEN || !WHATSAPP_PHONE_NUMBER_ID || !WHATSAPP_ADMIN_NUMBER) return false;
  const r=await fetch(`https://graph.facebook.com/v21.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`,{
    method:"POST",headers:{Authorization:`Bearer ${WHATSAPP_TOKEN}`,"Content-Type":"application/json"},
    body:JSON.stringify({messaging_product:"whatsapp",to:WHATSAPP_ADMIN_NUMBER,type:"text",text:{body:message}})
  });
  if(!r.ok) throw new Error("WhatsApp API notification failed");
  return true;
}
function notify(subject, message) {
  return Promise.allSettled([sendEmail(subject,message),sendWhatsApp(message)]);
}
app.post("/api/bookings", async (req,res)=>{
  const b=req.body||{};
  const required=["name","phone","service"];
  if(required.some(k=>!String(b[k]||"").trim())) return res.status(400).json({error:"Name, mobile number and service are required."});
  if(!/^[0-9+\-\s]{8,16}$/.test(b.phone)) return res.status(400).json({error:"Please enter a valid phone number."});
  const id="WW-"+Date.now().toString(36).toUpperCase()+"-"+crypto.randomBytes(2).toString("hex").toUpperCase();
  db.prepare(`INSERT INTO bookings(booking_id,name,phone,email,service,patient,address,pin,start_date,duration,shift,notes)
  VALUES(@booking_id,@name,@phone,@email,@service,@patient,@address,@pin,@start_date,@duration,@shift,@notes)`).run({
    booking_id:id,name:b.name.trim(),phone:b.phone.trim(),email:b.email||"",service:b.service,
    patient:b.patient||"",address:b.address||"",pin:b.pin||"",start_date:b.startDate||"",
    duration:b.duration||"",shift:b.shift||"",notes:b.notes||""
  });
  const msg=`New Well Work Home Care booking\nID: ${id}\nName: ${b.name}\nMobile: ${b.phone}\nService: ${b.service}\nAddress: ${b.address||"-"}\nPIN: ${b.pin||"-"}\nDate: ${b.startDate||"-"}\nShift: ${b.shift||"-"}`;
  await notify("New booking "+id,msg);
  res.status(201).json({success:true,bookingId:id,message:"Your request has been received. Our team will contact you."});
});
app.post("/api/enquiries", async (req,res)=>{
  const b=req.body||{};
  if(!b.name||!b.phone) return res.status(400).json({error:"Name and mobile number are required."});
  db.prepare("INSERT INTO enquiries(name,phone,message) VALUES(?,?,?)").run(b.name,b.phone,b.message||"");
  await notify("New website enquiry",`New enquiry\nName: ${b.name}\nPhone: ${b.phone}\nMessage: ${b.message||"-"}`);
  res.status(201).json({success:true,message:"Enquiry received."});
});
app.post("/api/jobs", async (req,res)=>{
  const b=req.body||{};
  if(!b.name||!b.phone||!b.role) return res.status(400).json({error:"Name, phone and role are required."});
  db.prepare("INSERT INTO job_applications(name,phone,email,role,experience) VALUES(?,?,?,?,?)")
    .run(b.name,b.phone,b.email||"",b.role,b.experience||"");
  await notify("New job application",`Job application\nName: ${b.name}\nPhone: ${b.phone}\nRole: ${b.role}\nExperience: ${b.experience||"-"}`);
  res.status(201).json({success:true,message:"Application received."});
});
/* Admin endpoints intentionally remain disabled until a production-grade
   authentication/session/role system is configured. Never expose raw records. */
app.get("/api/admin/*",(req,res)=>res.status(501).json({error:"Admin API is not enabled. Configure secure authentication before deployment."}));
app.get("/api/health",(req,res)=>res.json({ok:true,service:"Well Work Home Care"}));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Well Work Home Care running at http://localhost:${port}`));
