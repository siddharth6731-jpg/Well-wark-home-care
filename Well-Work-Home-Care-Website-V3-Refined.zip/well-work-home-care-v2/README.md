# Well Work Home Care — animated website v2

## Open the demo
Open `Well-Work-Home-Care-Animated-Demo.html` in Chrome. It is a self-contained visual demo; the forms show sample confirmations and do not save or send data.

## Run the website with backend
Requires Node.js 18+.
1. Run `npm install`
2. Copy `.env.example` to `.env` and configure SMTP/WhatsApp credentials.
3. Run `npm start`
4. Open http://localhost:3000

The backend starter supports booking, enquiry and job-application storage with SQLite and optional admin email / WhatsApp Cloud API notifications. Admin and employee dashboards, authentication and payment processing are not enabled in this version and must be implemented securely before production.

## Important image note
The newly generated team portrait shows all four team members in white branded coats. The profile tiles are crops from that generated team image; AI imagery is an approximation and is not a verified identity-preserving edit of each original portrait. Please obtain approval from each team member before publishing.
