const services=[
["Antiseptic Dressing","Wound-care dressing support following a clinician’s instructions.","🩹"],
["Sterilization Support","Support for safe care practices and infection-prevention routines.","🛡️"],
["Physiotherapy","Mobility and rehabilitation support as advised by a qualified professional.","🧘"],
["Nursing Care","Home nursing support based on assessed patient needs.","🩺"],
["Lab Test Collection","Coordination for eligible home sample collection services.","🧪"],
["Elder Care","Daily living assistance and companionship for older adults.","🤝"],
["Medical Equipment","Guidance on arranging suitable home-care equipment.","🩻"],
["Critical Care","Specialised home-care coordination subject to clinical assessment and availability.","❤️‍🩹"],
["Post-Operative Care","Recovery support after hospital discharge, as prescribed.","🏥"],
["Tracheostomy Care","Care support by appropriately trained staff under clinical guidance.","🫁"],
["Urinary Catheterization","Catheter-related care by trained personnel with appropriate prescription.","💧"],
["Colostomy Care","Stoma-care assistance and patient/family support.","🌿"],
["Supportive Care","Comfort-focused assistance and coordination for patients and families.","🫶"],
["Pregnancy, Women’s & Baby Care","Mother-and-baby support and care coordination.","🤱"]
];
const grid=document.getElementById("serviceGrid"),select=document.getElementById("serviceSelect");
services.forEach(([name,desc,ico])=>{const card=document.createElement("article");card.className="service reveal";card.innerHTML=`<div class="ico" aria-hidden="true"><span>${ico}</span></div><h3><span>${name}</span></h3><p>${desc}</p>`;grid.append(card);const opt=document.createElement("option");opt.value=name;opt.textContent=name;select.append(opt)});
document.getElementById("year").textContent=new Date().getFullYear();
document.getElementById("menuBtn").addEventListener("click",()=>document.getElementById("navLinks").classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(a=>a.addEventListener("click",()=>document.getElementById("navLinks").classList.remove("open")));
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");observer.unobserve(e.target)}}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));
function demoSubmit(id,resultId,msg){document.getElementById(id).addEventListener("submit",e=>{e.preventDefault();const out=document.getElementById(resultId);out.className="result";out.textContent=msg+" (Demo mode: no data is sent or saved.)";});}
demoSubmit("bookingForm","bookingResult","Request preview submitted. Sample Booking ID: WW-DEMO-2026.");
demoSubmit("jobForm","jobResult","Application preview received.");
